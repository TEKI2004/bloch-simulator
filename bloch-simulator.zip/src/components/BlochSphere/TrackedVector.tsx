
import { useMemo, useRef } from "react";
import StateVector from "./StateVector";
import HistoryCurve from "./HistoryCurve";

import { getHistorySegments } from "../../simulator/history";
import type { BlochVector } from "../../quantum/bloch";
import type { DisplayState } from "./vectorGrouping";

type Props = {
    vector: DisplayState;
    direction: BlochVector;
    label: string;
    mergedHidden: boolean;
    renderOrder: number;
    mergeAnimationKey: string;
    gateEditRevision: number;
    keepMergedDuringAnimation: boolean;
    gateMoveRevision: number;
};

export default function TrackedVector({
    vector,
    direction,
    label,
    mergedHidden,
    renderOrder,
    mergeAnimationKey,
    gateEditRevision,
    keepMergedDuringAnimation,
    gateMoveRevision,
}: Props) {
    const progressRef = useRef(1);

    const { initialState, gates, stepIndex } = vector;

    // Csak a kvantumállapot vagy a kapusor változásakor számoljuk újra.
    const history = useMemo(
        () => getHistorySegments(initialState, gates, stepIndex),
        [initialState, gates, stepIndex],
    );

    return (
        <>
            <HistoryCurve
                segments={history}
                color={vector.color}
                stepIndex={stepIndex}
                mode={vector.mode}
                gates={gates}
                progressRef={progressRef}
                gateEditRevision={gateEditRevision}
            />

            <StateVector
                direction={direction}
                color={vector.color}
                label={label}
                gates={gates}
                stepIndex={stepIndex}
                mode={vector.mode}
                mergedHidden={mergedHidden}
                renderOrder={renderOrder}
                mergeAnimationKey={mergeAnimationKey}
                progressRef={progressRef}
                ownLabel={vector.label}
                keepMergedDuringAnimation={keepMergedDuringAnimation}
                gateEditRevision={gateEditRevision}
                gateMoveRevision={gateMoveRevision}
            />
        </>
    );
}
